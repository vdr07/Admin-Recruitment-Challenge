#!/bin/bash

openssl pkcs12 -export -in /tmp/ca-cert.pem -inkey /tmp/ca-key.pem -out keystore.p12 -name tomcat -passout pass:test
openssl pkcs12 -in keystore.p12 -nokeys -out keystore.crt -passin pass:test
openssl pkcs12 -in keystore.p12 -nocerts -out tempkeystore.key -password pass:test -passin pass:test -passout pass:temptest
openssl rsa -in tempkeystore.key -out "keystore.key" -passin pass:temptest

rm tempkeystore.key
mv keystore.p12 /opt/tomcat/conf/